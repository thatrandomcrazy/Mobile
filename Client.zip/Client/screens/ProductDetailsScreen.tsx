// src/screens/ProductDetailsScreen.tsx
import React, { useState } from "react";
import { View, Text, Image, StyleSheet, Pressable, Modal } from "react-native";
import { useNavigation, useRoute, RouteProp } from "@react-navigation/native";
import type { NativeStackNavigationProp } from "@react-navigation/native-stack";

type RootStackParamList = {
  // נוסיף nonce כדי לוודא שהפרמטר משתנה בכל הוספה לעגלה
  Menu: { add: { id: string; title: string; price: number; qty: number } | null; nonce?: number };
  Cart: { items: any[] };
  ProductDetails: { id: string; title: string; price: number; image: string };
};

type ProductDetailsScreenNavigationProp = NativeStackNavigationProp<
  RootStackParamList,
  "ProductDetails"
>;
type ProductDetailsScreenRouteProp = RouteProp<RootStackParamList, "ProductDetails">;

export default function ProductDetailsScreen() {
  const navigation = useNavigation<ProductDetailsScreenNavigationProp>();
  const route = useRoute<ProductDetailsScreenRouteProp>();
  const { id, title, price, image } = route.params;

  const [qty, setQty] = useState(1);
  const [modalVisible, setModalVisible] = useState(false);
  const [adding, setAdding] = useState(false);

  const addToCart = () => {
    if (adding) return;
    setAdding(true);

    // אם Menu נמצא בתוך טאב, השתמש בגרסה המותאמת (מופיע למטה כהערה)
    navigation.navigate("Menu", {
      add: { id, title, price, qty },
      nonce: Date.now(), // טריגר ודאי לשינוי params
    });

    setModalVisible(true);
    setTimeout(() => {
      setModalVisible(false);
      setAdding(false);
      // אם אתה מעדיף לחזור אוטומטית לתפריט:
      // navigation.goBack();
    }, 1200);
  };

  return (
    <View style={{ flex: 1, alignItems: "center", padding: 16 }}>
      <Image
        source={{ uri: image || "https://via.placeholder.com/300x300?text=No+Image" }}
        style={styles.image}
      />
      <Text style={styles.title}>{title}</Text>
      <Text style={styles.price}>₪{price}</Text>
      <Text style={styles.description}>Delicious burger/junk food item.</Text>

      <View style={styles.qtyContainer}>
        <Pressable onPress={() => setQty((q) => Math.max(1, q - 1))} style={styles.qtyButton}>
          <Text>-</Text>
        </Pressable>
        <Text style={styles.qtyText}>{qty}</Text>
        <Pressable onPress={() => setQty((q) => q + 1)} style={styles.qtyButton}>
          <Text>+</Text>
        </Pressable>
      </View>

      <Pressable onPress={addToCart} style={[styles.addButton, adding && { opacity: 0.7 }]} disabled={adding}>
        <Text style={{ color: "#fff" }}>{adding ? "Adding..." : "Add to Cart"}</Text>
      </Pressable>

      <Modal visible={modalVisible} transparent animationType="fade">
        <View style={styles.modal}>
          <Text style={{ color: "#fff" }}>✓ Added to cart</Text>
        </View>
      </Modal>
    </View>
  );
}

/**
 * אם ה־Menu נמצא בתוך טאב בשם "MenuTab" והמסך הפנימי נקרא "Menu",
 * החלף את ה־navigate ב:
 *
 * navigation.navigate("MenuTab" as never, {
 *   screen: "Menu",
 *   params: { add: { id, title, price, qty }, nonce: Date.now() },
 * } as never);
 */

const styles = StyleSheet.create({
  image: { width: 220, height: 220, marginBottom: 16, borderRadius: 12 },
  title: { fontSize: 20, fontWeight: "bold" },
  price: { fontSize: 18, marginBottom: 8 },
  description: { fontSize: 14, marginBottom: 16, textAlign: "center" },
  qtyContainer: { flexDirection: "row", alignItems: "center", marginBottom: 16 },
  qtyButton: { borderWidth: 1, borderColor: "#ccc", padding: 8, borderRadius: 6, minWidth: 40, alignItems: "center" },
  qtyText: { marginHorizontal: 16, fontSize: 16, minWidth: 24, textAlign: "center" },
  addButton: { backgroundColor: "tomato", padding: 12, borderRadius: 8, minWidth: 160, alignItems: "center" },
  modal: { flex: 1, justifyContent: "center", alignItems: "center", backgroundColor: "#00000080" },
});
