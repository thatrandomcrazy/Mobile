export const MENU = [
  { id: "b1", title: "Classic Burger", price: 42, image: "https://..." },
  { id: "b2", title: "Cheese Burger", price: 46, image: "https://..." },
  { id: "s1", title: "Fries", price: 18, image: "https://..." },
  { id: "d1", title: "Cola", price: 10, image: "https://..." },
];
